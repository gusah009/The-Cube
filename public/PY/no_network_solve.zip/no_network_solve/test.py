import solver

defstr = "FLBDULBUURBLLRRLFBRFFBFULUFDRUDDRLLRRBURLUDFBUDDDBBDFF"
print(solver.solve(defstr))